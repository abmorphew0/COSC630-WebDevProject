<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - General Authentication Process</title>
      <style>
        @import url("../../CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="../../welcome.php"><img src='../../../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../../../index.php">Log-Out</a>
                <h2 style="margin-bottom: 0;">Sign-Up Process</h2>
                <p><input type="button" value="General Process" onclick="window.location.href='../accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='../../Authentication/authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='../../Future/future.php'"></p>
            </div>
          <div id="authorSect">
            <input type="button" value="Sign-Up" onclick="window.location.href='sign-upInfo.php'">
              <input type="button" value="Login" onclick="window.location.href='../login/loginInfo.php'">
              <input type="button" value="Two-Factor Authentication" onclick="window.location.href='../2FA/2faInfo.php'">
              <br>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../../../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
          </div>
          <div id="infoSect">
              <p><b>In this sub-section you will learn about the sign-up process:</b><br><br>
              As you have experiences when accessing this site - you needed to provide some information as well as an email and password. All of these components, together, provide values associated with your
              account for this website. As the image below shows, all of these values inputted by you will be stored in a secure database (we will mention this further below):
              <center><img src="../../../Artifacts/Account Images/Sign-Up/sign-up.png"></center><br><br></p>
              <p>Each component plays a role in this website - you may have noticed. Let go through each component<br><br>
              <b>First Name</b> - this value is primarily used to save the name provided at sign-up for the purposes of outputting your name at the top of the Welcome page.
              This value is saved within a database alongside the other values representing you entire record.<br><br>
              <b>Last Name</b> - this value is, like the first name, primarily used to save the name provided for the purposes of outputting your name at the top of the Welcome page.
              This value is also saved next to the first name in your database record.<br><br>
              <b>Title</b> - entirely for interest and fun, the title value is for the purposes of formally outputting your name at the top of the Welcome page.
              This value is also saved next to the first and last name in your database record.<br><br>
              <b>Email</b> - this value, importantly, is your username when accessing this site. It is also the email address that the two-factor authentication code will be sent to.
              This value is also saved next to the first, last names, and title in your database record. This value also is the primary value that links your account with the authentication process
              (so we know we are only working with your record).<br><br>
              <b>Password</b> - interestingly, you may have noticed on the diagram, that a password stored in a database looks complicated - what if I were to mention that the accounts password
              for that record is 'Hello'? This is because, for security reasons, passwords are never saved in "plaintext" (readable/understandable language). Rather, they are stored as a "hash".<br><br>
              <em><b>Hash</b> - one-way (cannot be reversed) message transformation of a "plaintext" value into a message digest (a combination of characters that represent that word)</em><br>
              What this means is that we are never communicating through the Internet with your "plaintext" password - making sure no unauthorized user can access your account and get onto this website using a false authentication.
              <br><br><br>
              When you sign-up for an account on this website, your record will be stored permanently (as of this moment). But, signing-up for an account allows you to consistently come back to this page with the
              credentials you determined.
              </p>
          </div>
        </div>
    </div>
  </body>
</html>
