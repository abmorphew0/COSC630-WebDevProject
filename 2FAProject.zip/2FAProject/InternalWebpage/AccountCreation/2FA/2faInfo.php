<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - General Authentication Process</title>
      <style>
        @import url("../../CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="../../welcome.php"><img src='../../../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../../../index.php">Log-Out</a>
                <h2 style="margin-bottom: 0;">Two-Factor Authentication Process</h2>
                <p><input type="button" value="General Process" onclick="window.location.href='../accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='../../Authentication/authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='../../Future/future.php'"></p>
            </div>
          <div id="authorSect">
            <input type="button" value="Sign-Up" onclick="window.location.href='../sign-up/sign-upInfo.php'">
              <input type="button" value="Login" onclick="window.location.href='../login/loginInfo.php'">
              <input type="button" value="Two-Factor Authentication" onclick="window.location.href='2faInfo.php'">
              <br>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../../../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
          </div>
          <div id="infoSect">
              <p><b>In this sub-section you will learn about the two-factor authentication process:</b><br><br>
              So, at this point, you might be wondering - I still don't know what this two-factor authentication is? <em>Well here you go!</em><br><br>
              In simple terms, two-factor authentication is when we use more than one form/mode of authentication (see the Authentication page to get more detail).<br><br>
              In the context of our site, this is in regards to the PIN sent to your account email after sign-up or login. It looks something like this:
              <center><img src="../../../Artifacts/Account Images/2FA/2fa.png"></center><br><br></p>
              <p>Your first-factor authentication was the use of a username/email and password (something you know). When you entered these, and were correctly verified, you are "verified". But, since username/email
                and password authentication is dangerously vulnerable to brute-force or known password attacks (i.e., knowing the hash value associated with a password) - through very simple processes, like looking over one's
                shoulder - we should not be primarily using this method by itself.<br><br>
                In our two-factor authentication methods, we choose a second, different mode (something you have) to further verify you are who you are. In simple terms, if you have access to an account based email,
                then you are a verified individual (as most people should not be sharing email account access information). We can use this to send a one-time code for you to enter into an input field for verification of
                that code. <br><br>
                The way we do that is by <b>(1)</b> generating a code <b>(2)</b> saving the code to a temporary database table - linked to your email <b>(3)</b> emailing your code to your account email
                <b>(4)</b> verifying the code entered with the code saved in the database <b>(5)</b> Pin gets deleted from the database <br><br>

                By specifying a one-time PIN, providing that PIN to the user, and then deleting that PIN, then we confirm that the user is who they are by verifying something they have (albeit temporarily)<br><br>
                Hence the reason why, when you enter the correct code, you are directed to this site. <b><em>You've been verified</em></b>
          </div>
        </div>
    </div>
  </body>
</html>
