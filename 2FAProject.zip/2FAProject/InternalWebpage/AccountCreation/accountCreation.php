<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - General Authentication Process</title>
      <style>
        @import url("../CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="../welcome.php"><img src='../../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../../index.php">Log-Out</a>
                <h2 style="margin-bottom: 0;">The Authentication Process</h2>
                <p><input type="button" value="General Process" onclick="window.location.href='accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='../Authentication/authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='../Future/future.php'"></p>
            </div>
          <div id="authorSect">
            <input type="button" value="Sign-Up" onclick="window.location.href='../AccountCreation/sign-up/sign-upInfo.php'">
              <input type="button" value="Login" onclick="window.location.href='../AccountCreation/login/loginInfo.php'">
              <input type="button" value="Two-Factor Authentication" onclick="window.location.href='../AccountCreation/2FA/2faInfo.php'">
              <br>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
          </div>
          <div id="infoSect">
              <!--Title Box and buttongs and logout goes here-->
              <p><b>In this section you will learn about what goes on behind the scenes of this website to authenticate you at sign-up or login:</b><br><br>
              To understand the entire entire two-factor authentication process, a diagram below provides an illustrative representation of the steps involved - <br><br>
              <center><img src="../../Artifacts/Welcome/2FA Process.png" alt="2FA Process Diagram"></center><br><br><br>
              Please use the sub-pages to the left to learn about each step/process</p>
          </div>
        </div>
    </div>
  </body>
</html>
