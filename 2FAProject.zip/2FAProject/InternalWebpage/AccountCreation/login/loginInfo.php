<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - General Authentication Process</title>
      <style>
        @import url("../../CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="../../welcome.php"><img src='../../../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../../../index.php">Log-Out</a>
                <h2 style="margin-bottom: 0;">Login Process</h2>
                <p><input type="button" value="General Process" onclick="window.location.href='../accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='../../Authentication/authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='../../Future/future.php'"></p>
            </div>
          <div id="authorSect">
            <input type="button" value="Sign-Up" onclick="window.location.href='../sign-up/sign-upInfo.php'">
              <input type="button" value="Login" onclick="window.location.href='loginInfo.php'">
              <input type="button" value="Two-Factor Authentication" onclick="window.location.href='../2FA/2faInfo.php'">
              <br>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../../../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
          </div>
          <div id="infoSect">
              <p><b>In this sub-section you will learn about the login process:</b><br><br>
              Seemingly, when you get to this point, you are a returning user (you already have an account). Where prompted, you are asked for your username/email and password credentials for account authentication.<br><br>
              As shown in the image, we authenticate the user for the first time using these values entered.
              <center><img src="../../../Artifacts/Account Images/Log-In/login.png"></center><br><br></p>
              <p>The first order in verifying an account and the credentials entered is to check the database as to if there is a record with the provided email (if we return a positive result - i.e. 1 record is returned). When a record is found
              we can ask the database for the password associated with that record. <br><br><br>
              Remember, passwords are hashed from the database - to verify the password entered (plaintext) with the hash, we need to hash the inputted password and compare both hashes (the scripting language used for this website
              already has this functionality built-in). As a learner, you just need to understand that the first authentication is comparing username/email and passwords entered versus that saved for your account.
              </p>
          </div>
        </div>
    </div>
  </body>
</html>
