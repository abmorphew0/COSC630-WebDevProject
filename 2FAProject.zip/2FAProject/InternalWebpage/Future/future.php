<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - Welcome</title>
      <style>
        @import url("../CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="welcome.php"><img src='../../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../../index.php">Log-Out</a>
                <h2 style="margin-bottom: 0;">Future of Two-Factor Authentication</h2>
                <p><input type="button" value="General Process" onclick="window.location.href='../AccountCreation/accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='../Authentication/authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='future.php'"></p>
            </div>
          <div id="authorSect">
            <h6 style="margin:auto">Aaron Morphew</h6>
            <h6 style="margin: auto;" class="hFont">Frostburg State University</h6>
            <h6 style="margin: auto" class="hFont">Dr. Michael Flinn</h6>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
            <p style="margin: auto"> <em><u>Summer 2022</u></em> </p>
          </div>
          <div id="infoSect">
              <p><b>In this section we will discuss the future of two-factor/multi-factor authentication</b><br><br>
                As the trend of digital users continues to climb, more and more people are going to be accessing sites, creating accounts, consistently logging into
                websites to read, interact, etc. This means more people are going to be using authentication services provided by the websites that they are accessing. <br><br>
                With the growth of at-home work, and the prevalence of easily accessible devices connected to the Internet - it is understandable as to why we are seeing the growth
                of two-factor authentication:
                <center><img src="../../Artifacts/Future Images/growth.jpg" alt="growth image">
                  <figcaption>Duo Security - 2021 State of the Auth - 2FA Growth</figcaption></center></p>
              <p>With further data, we can see where the common applicable usage of two-factor authentication are - notice the realative importance of these focus-areas
                when it comes to the need for proper authentication (expecially banking and finance):
                <center><img src="../../Artifacts/Future Images/focus-areas.jpg" alt="focus areas image">
                  <figcaption>Duo Security - 2021 State of the Auth - Focus Areas</figcaption></center></p>
              <p>When we look at delivery methods currently being used, we see that the majority of people use either SMS (text messaging) or email services
                in order to receive two-factor credentials:
                <center><img src="../../Artifacts/Future Images/methodUsed.jpg" alt="methods used image">
                <figcaption>Duo Security - 2021 State of the Auth - Methods Currently Employed</figcaption></center></p>
              <p>What is great about this is the realative access and ease of use involved with these processes - two-factor authentication truely is a simple to use, yet
                secure process that people are adapting to. Just look at this data from users when asked what methods they would choose in the future:
                <center><img src="../../Artifacts/Future Images/delivery.jpg" alt="future methods image">
                <figcaption>Duo Security - 2021 State of the Auth - Methods Users Would Use in the Future</figcaption></center></p>
              <p>Even biometrics are in the mix, we all more than likely use biometrics for our smartphone access at this point - but biometrics are on the rise
                through simple, cheaper, effective means:
                <center><img src="../../Artifacts/Future Images/biometrics.jpg" alt="biometrics image">
                <figcaption>Duo Security - 2021 State of the Auth - Biometric Growth</figcaption></center></p>
              <p>As an example, this is data pertaining to Twitter users use of two-factor authentication services - we consistently see increased enrollment using
                the common means of delivery:
                <center><img style="width: 50%; height: 70%;" src="../../Artifacts/Welcome/Twitter 2FA.jpg" alt="biometrics image">
                <figcaption>Twitter Two-Factor Authentication Data</figcaption></center></p>
              <p>By the end of this, I think it is safe to say that two-factor/multi-factor authentication is the future of easy, accessible Internet/digital security for everyone
                By combining different modes of authentication, people are more secure on the Internet - it becomes harder for attackers to gain access to systems which are
                protected by a number of authentication methods - and they are all easy to use and are becoming readily available<br><br>
                With such, I will leave you with this - think about your Internet security, think about enrolling in two-factor/multi-factor authentication for the betterment of your
                online security. I hope you enjoyed this website, feel free to come back anytime!</p>
          </div>
        </div>
    </div>
  </body>
</html>
