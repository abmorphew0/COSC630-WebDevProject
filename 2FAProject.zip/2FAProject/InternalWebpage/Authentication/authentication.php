<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - What is Authentication?</title>
      <style>
        @import url("../CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="../welcome.php"><img src='../../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../../index.php">Log-Out</a>
                <h2 style="margin-bottom: 0;">What is Authentication?</h2>
                <p><input type="button" value="General Process" onclick="window.location.href='../AccountCreation/accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='../Future/future.php'"></p>
            </div>
          <div id="authorSect">
            <input type="button" value="Single-Factor" onclick="window.location.href='../Authentication/single-factor/single-factorInfo.php'">
              <input type="button" value="Something You Are" onclick="window.location.href='../Authentication/something-you-are/something-you-areInfo.php'">
              <input type="button" value="Something You Have" onclick="window.location.href='../Authentication/something-you-have/something-you-haveInfo.php'">
              <input type="button" value="Something You Know" onclick="window.location.href='../Authentication/something-you-know/something-you-knowInfo.php'">
              <br>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
          </div>
          <div id="infoSect">
            <p><b>In this section you will learn about authentication - what does that mean/how do we authenticate an individual?</b><br><br>
            Simply put, authentication is the act of proving/verifying that someone is who they say they are. Generally, people have methods/credentials in which they can prove their identity.<br><br>
            Think of this as the purpose of a driver's license or identification card - that document provides acknowledgement to all who ask for it that you are who you are. This method uses the
            Something You Have mode of authentication (further sub-pages will explain the different modes).<br><br>
            In other scenarios, you may be asked to provide a code or number (PIN) to prove your identity. The act of knowing the PIN proves that you are who you are. This method uses the Something You Know
            mode of authentication. <br><br>
            In certain scenarios, in a growing number of scenarios, biometric data - like fingerprints, eyes, facial recognition, etc. - can be used to verify you are who you are. In most cases, we can accurately
            prove someones is who they are based on some unique characteristic that makes them uniquely them. This method uses the Something You Are mode of authentication. <br><br>
            In understanding authentication think of it as such: <br><br>
            <b>Single-Factor:</b> Something You Have, or Something You Know, or Something You Are <br><br>
            <b>Multi-Factor:</b> Something You Have, and/or Something You Know, and/or Something You Are <br><br>
            Please use the sub-pages to the left to learn about each step/process</p>
          </div>
        </div>
    </div>
  </body>
</html>
