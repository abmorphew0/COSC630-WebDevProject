<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - What is Authentication?</title>
      <style>
        @import url("../../CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="../../welcome.php"><img src='../../../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../../../index.php">Log-Out</a>
                <h2 style="margin-bottom: 0;">Something You Are Authentication</h2>
                <p><input type="button" value="General Process" onclick="window.location.href='../../AccountCreation/accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='../authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='../../Future/future.php'"></p>
            </div>
          <div id="authorSect">
            <input type="button" value="Single-Factor" onclick="window.location.href='../single-factor/single-factorInfo.php'">
              <input type="button" value="Something You Are" onclick="window.location.href='something-you-areInfo.php'">
              <input type="button" value="Something You Have" onclick="window.location.href='../something-you-have/something-you-haveInfo.php'">
              <input type="button" value="Something You Know" onclick="window.location.href='../something-you-know/something-you-knowInfo.php'">
              <br>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../../../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
          </div>
          <div id="infoSect">
              <p><b>In this sub-section you will learn about the Something You Are mode of authentication:</b><br><br>
              Probably the most interesting of all modes of authentication. Something You Are takes advantage of who you are, your unique characteristics that make you -you (biometric information). It is difficult to replicate your
              uniqueness, thus it is a great mode to use when only single-factor authentication is available - even though it should be used in multi-factor authentication. <br><br>
              There are different characteristics which are commonly used, I will go through some of them: <br><br>
              <b>Fingerprints</b><br>
                Biometric usage of fingerprints is centered around the unqiue pattern created by the peaks and valleys of you skin on your fingers.<br>
                To accomplish this verification we <b>(1)</b> Take an image/scan of your current finger used for authentication (think about when you register your finger on your new smartphone);
                  <b>(2)</b> Images then are securely stored on your device; <b>(3)</b> To gain access, you scan your finger again - then the recognition software will compare your saved image/scan and
                  the new scan to provide access<br>
                  <center><img src="../../../Artifacts/Authentication Images/Something-You-Are/fingerprint.jpg" alt="fingerprint image"></center></p>
              <p><b>Iris/Retina (Eye)</b><br>
                Biometric usage  of iris or retina data is based on the unqiue patterns of your Iris (the colorful part of your eye) or your Retina (the region behind the Iris). Retina patterns are based on the
                  structure of blood vessels in the back-side of your eye. To accomplish this verification we <b>(1)</b> Take an image/scan of your Iris or Retina using a UV camera and capturing a picture;
                  <b>(2)</b> UV images are converted to digital code and are securely stored on your device; <b>(3)</b> To gain access, you scan your eyes again - then the recognition software will compare the saved
                  image and the new image to approve access <br>
                  <center><img style="width: 18%; height: 85%;" src="../../../Artifacts/Authentication Images/Something-You-Are/iris.jpg" alt="iris image"><img src="../../../Artifacts/Authentication Images/Something-You-Are/retina.jpg" alt="retina image"></center></p>
                <p><b>Voice</b><br>
                  Biometric voice recognition software is based on the way you speak. Analog (sound) can be converted into digital signals (this is how telephones work) and the unique patterns, tones, pitch, and volume
                  of ones speech can be identifiable (like how we can recognize people by the sound of there voice - just digital). To accomplish this verification we <b>(1)</b> Capture speech information - generally this is through a
                  recording of a certain sentence that allows the voice recognition to capture voice characteristics. <b>(2)</b> Information/patterns/accents are stored in secure databases <b>(3)</b> To gain access, you speak into a microphone,
                  the voice recognition software matches tonal qualities to incoming sound to approve access. <br>
                  <center><img style="width: 18%; height: 85%;" src="../../../Artifacts/Authentication Images/Something-You-Are/voice.png" alt="voice image"></center></p>
              <p>These are only a snippet of the possible biometric data that can be collected - not just physical, but mental characteristics as well. <br><br>
                Just know that whenever you are providing a information based off of physical characteristics you are being authenticated by Something You Are.</p>
          </div>
        </div>
    </div>
  </body>
</html>
