<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - What is Authentication?</title>
      <style>
        @import url("../../CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="../../welcome.php"><img src='../../../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../../../index.php">Log-Out</a>
                <h2 style="margin-bottom: 0;">Something You Know Authentication</h2>
                <p><input type="button" value="General Process" onclick="window.location.href='../../AccountCreation/accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='../authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='../../Future/future.php'"></p>
            </div>
          <div id="authorSect">
            <input type="button" value="Single-Factor" onclick="window.location.href='../single-factor/single-factorInfo.php'">
              <input type="button" value="Something You Are" onclick="window.location.href='../something-you-are/something-you-areInfo.php'">
              <input type="button" value="Something You Have" onclick="window.location.href='../something-you-have/something-you-haveInfo.php'">
              <input type="button" value="Something You Know" onclick="window.location.href='something-you-knowInfo.php'">
              <br>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../../../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
          </div>
          <div id="infoSect">
              <p><b>In this sub-section you will learn about the Something You Know mode of authentication:</b><br><br>
              As mentioned before, something you know authentication is the most common basis for authentication when you meet any website that uses
              usernames and passwords or access pin requirements. <br><br>
              Simply put, you know something that other people are not suppose to know - your passwords are suppose to be kept secret from other people,
              you are not suppose to shared personal identification numbers (PINs) to other people. <br><br>
              We use passwords and pins all the time because they are realitvely easy to remember - an many people today store their passwords in digital
              "vaults" or password management systems which make it easier to access passwords (when they are forgotten) or even auto-fill input boxes
              when prompted for a password. <br><br>
              PINs, like your bank ATM pin assoicated with your debit card works the same way - its a recognizable, easy to remember PIN used to authenticate the user
              when a debit card is inserted into a machine.
              <center><img style="width: 18%; height: 85%;" src="../../../Artifacts/Authentication Images/Something-You-Know/password.jpg" alt="iris image"><img src="../../../Artifacts/Authentication Images/Something-You-Know/pin.jpg" alt="pin image"></center></p>
              <p>However, I hope you can see a glaring deficiency in this method - a single point of failure based on human nature. <br><br>
                When we hold information that is suppose to be secret, humans are succeptable to social engineering - whereas we place trust (even if false) into something/someone
                who, in turn, uses that information gathered to complete a malicious task. Humans can also be careless regarding the security of information - many people
                write passwords down so they do not forget them - however these notes are succeptable to people looking for information - and they can easily steal a written
                password.<br><br>

                The best way to use this mode of authentication is in conjunction with other modes - just like this website employs. This is so, even if someone were to
                have access to your username and password, they wouldn't be able to access any sites with that alone.<br><br>
                So remember, whenever you are providing a information based off of something you know/memorized for yourself you are being authenticated by Something You Know.</p>

          </div>
        </div>
    </div>
  </body>
</html>
