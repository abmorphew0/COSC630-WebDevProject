<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - What is Authentication?</title>
      <style>
        @import url("../../CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="../../welcome.php"><img src='../../../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../../../index.php">Log-Out</a>
                <h2 style="margin-bottom: 0;">Something You Have Authentication</h2>
                <p><input type="button" value="General Process" onclick="window.location.href='../../AccountCreation/accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='../authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='../../Future/future.php'"></p>
            </div>
          <div id="authorSect">
            <input type="button" value="Single-Factor" onclick="window.location.href='../single-factor/single-factorInfo.php'">
              <input type="button" value="Something You Are" onclick="window.location.href='../something-you-are/something-you-areInfo.php'">
              <input type="button" value="Something You Have" onclick="window.location.href='something-you-haveInfo.php'">
              <input type="button" value="Something You Know" onclick="window.location.href='../something-you-know/something-you-knowInfo.php'">
              <br>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../../../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
          </div>
          <div id="infoSect">
              <p><b>In this sub-section you will learn about the Something You Have mode of authentication:</b><br><br>
              For many of you, if you have in your possession a document, identification card (like a driver's license or employer provided access card) than
              you are already using this mode of authentication. Whenever we use something that you possess - directly or indirectly - to verify your identity
              we are following this mode of authentication. <br><br>
              Importantly, do not get Something You Have authentication mixed with Something You Know authentication - sometimes people will say that they "have"
              a username and password that they use (implying some possessive nature of the memorized information) - but, importanty, Something You Have authentication
              is based around <b>physical possession</b> in which a device proves authentication, or provides a means of providing a digital authenticated information. <br><br>
              To illustrate the point, the following two type of devices commonly used to authenticate an individual are:<br><br>
              <b>Smartcards</b><br>
                Smartcards today offer multiple forms of authentication. Generally, the information printed on them, like personal identifiable information can be used
                to directly authenticate a person just by reading the information (much like how your driver's license has printed information to describe you). The second way
                smartcards can be used is as an "access point". Smartcards generally come with RF ID and physical chips, which when scanned or inserted into a system provide
                access to internal information. For example, CACs (Common Access Cards) used in the U.S. Government are used to access individual certificates - these certificates then
                identify you to an internal/external system when required.<br><br>Even in access controlled environments the role of a smart card is a link between your physical presence and
                your authorized account - when you scan a smartcard at a readers (like a door reader for example), the access control system will determine if your account has access rights
                to the area you are trying to get into - and will unlock the requested door or not depending on the accounts access rights<br>
                  <center><img style="height: 75%; width: 40%" src="../../../Artifacts/Authentication Images/Something-You-Have/smartcard.jpg" alt="smartcard image"></center></p>
            <p><b>Tokens</b><br>
                Tokens, like smartcards, provide access to something based on a characteristic they link a person to, or something you physically have stored on the device.<br><br>
                Commonly, a cryptographic key is stored on a token, only accessible by inserting the token into a digital device. As such, you would need to carry this token
                with you when accessing devices to prove your identity.<br><br>
                As shown in the image below, most token devices are small USB devices which have a stored internal code which, when inserted, authenticates the user to provide
                access to that device.<br>
                  <center><img style="height: 70%; width: 35%" src="../../../Artifacts/Authentication Images/Something-You-Have/token.jpg" alt="token image"></center></p>
            <p>These are only two different types of authenticating devices used, there are more methods we can identify someone through someting they have.<br><br>
                Just know that whenever you are providing a information based off of something you physically possess you are being authenticated by Something You Have.</p>
          </div>
        </div>
    </div>
  </body>
</html>
