<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - What is Authentication?</title>
      <style>
        @import url("../../CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="../../welcome.php"><img src='../../../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../../../index.php">Log-Out</a>
                <h2 style="margin-bottom: 0;">Single-Factor Authentication</h2>
                <p><input type="button" value="General Process" onclick="window.location.href='../../AccountCreation/accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='../authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='../../Future/future.php'"></p>
            </div>
          <div id="authorSect">
            <input type="button" value="Single-Factor" onclick="window.location.href='single-factorInfo.php'">
              <input type="button" value="Something You Are" onclick="window.location.href='../something-you-are/something-you-areInfo.php'">
              <input type="button" value="Something You Have" onclick="window.location.href='../something-you-have/something-you-haveInfo.php'">
              <input type="button" value="Something You Know" onclick="window.location.href='../something-you-know/something-you-knowInfo.php'">
              <br>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../../../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
          </div>
          <div id="infoSect">
              <p><b>In this sub-section you will learn about single-factor authentication:</b><br><br>
                As you might have already guessed/assumed as you have been reading through this website, single-factor authentication only uses a single-mode to verify one's identity.<br><br>
                The most common single-factor authentication mode is the usage of usernames and passwords. As mentioned before, this only fulfills one mode of authentication - something you know.<br><br>
                If we see from the diagram below, single-factor with username and passwords are as such:
                <center><img src="../../../Artifacts/Authentication Images/Single-Factor/single-factor.png"></center><br><br></p>
                <p>Of course, we are not strictly stuck to using usernames/passwords (something you know), but this could include PINs which are memorized and used time after time. <br><br>Or we can talk about the use
                  of identification cards (government issued, employer issued, etc.) to verify your identity (something you have). <br><br>Plus, we cannot forget about the unqiueness of yourself. We all have different characteristics.
                  The usage of such characteristics in proving identity is easily attainable and readily acceptable (think about your facial recognition software, or fingerprint scanners on your phone) - you are already using
                  this form of authentication everyday.<br><br>
                  What is important to understand is that when we only use <b>one (1)</b> of these methods for verification - this is Single-Factor Authentication. The downside of primarily using this form is the prevalence of a
                  single point of failure - whereas someone steals your credentials, and thus they have access.
          </div>
        </div>
    </div>
  </body>
</html>
