<?php session_start(); ?>
<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - Welcome</title>
      <style>
        @import url("CSSInternal/internalStyle.css");
      </style>
  </head>
  <body>
    <div id="mainBody">
        <div id="innerbody">
            <div id="imageBox">
                <a style="margin: auto" href="welcome.php"><img src='../Artifacts/Logo/logo.png' alt='Website Logo' height="168px"></a>
              </div>
            <div id="titleBox">
                <a href="../index.php">Log-Out</a>
                <?php
                $title = $_SESSION['Title'];
                $fName = $_SESSION['Fname'];
                $lName = $_SESSION['Lname'];
                echo "<h2 style='margin-bottom: 0;'>Welcome, $title $fName $lName </h2>";
                ?>
                <p><input type="button" value="General Process" onclick="window.location.href='../InternalWebpage/AccountCreation/accountCreation.php'">
                  <input style="width:32%;" type="button" value="Authentication" onclick="window.location.href='../InternalWebpage/Authentication/authentication.php'">
                  <input style="width:32%;" type="button" value="Future" onclick="window.location.href='../InternalWebpage/Future/future.php'"></p>
            </div>
          <div id="authorSect">
            <h6 style="margin:auto">Aaron Morphew</h6>
            <h6 style="margin: auto;" class="hFont">Frostburg State University</h6>
            <h6 style="margin: auto" class="hFont">Dr. Michael Flinn</h6>
            <center><img style="width: 90%; height: 65%; margin-top: 2%; margin-bottom: 0%;" class="authorImg" src='../Artifacts/Author Image/CanvasPic.jpg' alt='Author Image'></center>
            <p style="margin: auto"> <em><u>Summer 2022</u></em> </p>
          </div>
          <div id="infoSect">
              <p><em><b>Author Note</b>- Welcome, I am glad to see that you are able to access this site (and that the user authentication is working as it should). I hope it was relatively easy to go through the two-factor
                                  authentication process - and I hope you take the time to go through this site and learn about the process you just experienced.</em><br><br>
              The purpose of this website is to teach through experience - you have experienced a simple two-factor authentication process, now it is time to learn a little about what that means.<br><br>
              <b>How to use this site:</b><br><br>
              <u>Page Selections</u> - three buttons are at the time of the website (below your name). They include:<br><br>
              <em>General Process</em> - explanations of the two-factor authentication process you just went through. <br>
              <em>Authentication</em> - explanations on the components of authentication and the modes of authentication. <br>
              <em>Future</em> - discussion on the future of two-factor/multi-factor authentication including usages/applications, general exposure, acceptance - with how each factor has grown in recent years.<br><br>
              <u>Sub-Page Selection</u> - information in the General Process and Authentication pages are divided into sub-pages. They include:<br><br>
              <em>General Process</em><br>
              &nbsp&nbsp&nbsp&nbsp<b>Sign-Up</b> - discussion on the sign-up process - why you needed to provide such information, where is that information stored?<br>
              &nbsp&nbsp&nbsp&nbsp<b>Login</b> - discussion on the login process - how it links information provided in the sign-up to authenticat a user?<br>
              &nbsp&nbsp&nbsp&nbsp<b>Sign-Up</b> - discussion on the two-factor authentication process - how are codes generated, how are codes sent to users, how do we authenticate this code at time of login?<br><br>

              <em>Authentication</em><br>
              &nbsp&nbsp&nbsp&nbsp<b>Single-Factor</b> - discussion about single-factor authentication - what is it, how is it used, how do we make this more secure?<br>
              &nbsp&nbsp&nbsp&nbsp<b>Something You Are</b> - discussion about the first mode of authentication, something you physically are - what does this entail, what are the common applications?<br>
              &nbsp&nbsp&nbsp&nbsp<b>Something You Have</b> - discussion about the second mode of authentication, something you have in your possession - what does this entail, what are the common applications?<br>
              &nbsp&nbsp&nbsp&nbsp<b>Something You Know</b> - discussion about the third mode of authentication, something you know - what does this entail, what are the common applications<br><br>

              At any point in time, you can click on the logo image in the top left corner of the page to be redirected to this Welcome page, or if you get lost.<br><br>
              When you are done reading, you can log-out of the website (but you must log back in again before accessing the site once more).<br><br>
              Thanks, have fun!
              </p>
          </div>
        </div>
    </div>
  </body>
</html>
