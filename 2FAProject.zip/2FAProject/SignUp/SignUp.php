<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../phpmailer/vendor/autoload.php';
   //Establishes the Connection to the Database
   //require '../dbConnect.php';
   $dbConnect = mysqli_connect("138.88.73.64", "amorphew", "Climatal11!", "amorphew");
   //prints based on if the connection is correct
   if($dbConnect == false) {
     print "Unable to connect to the database: " . mysqli_errno();
   }
   else {
      if(isset($_POST['Submit']))     //Grabs the array of data to be entered into the database
      {
          $Fname = $_POST['FirstName'];   //defining the First Name Variable
          $Lname = $_POST['LastName'];   //Defining the Last Name Variable
          $title = $_POST['title'];   //defining the title variable
          $email = $_POST['EmailAddr'];   //Defining the email variable
          $password = password_hash($_POST['Pass'], PASSWORD_DEFAULT); //defining the password variable (1st one) and hashing it
          $password2 = password_verify($_POST['Pass2'], $password);   //defining the password2 variable and verifying that it is similar to the first password entered

          $tableName = 'user_accounts';
          //Insert Query of SQL
          $query = "INSERT INTO $tableName (Fname, Lname, Title, Email, Password) VALUES ('$Fname','$Lname', '$title', '$email','$password');";

          //If the passwords entered are not similar
          if($password == "")
          {
            //echo a error - re-enter information
            echo "<script type ='text/javascript'>alert('Enter a valid password.')</script>";
          }
          elseif($email == "")
          {
            //echo an error - enter an email addresss
            echo "<script type ='text/javascript'>alert('Enter a valid email address.')</script>";
          }
          elseif($Fname =="" || LName=="")
          {
            echo "<script type ='text/javascript'>alert('Please enter all input fields')</script>";
          }
          elseif(!$password2)
          {
            //echo an error - the two passwords do not match (need to match each other)
            echo "<script type ='text/javascript'>alert('Passwords do not match.')</script>";
          }
          //Else - paswords are the same - continue to populate the database
          else
          {
            //query the database with the query on line-18
            mysqli_query($dbConnect, $query);

            //$string1 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            function random_strings($length_of_string)
            {

               // String of all alphanumeric character
               $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';

               // Shufle the $str_result and returns substring
               // of specified length
               return substr(str_shuffle($str_result), 0, $length_of_string);
             }
             //create a 6-digit random string using the function above
             $shuffle = random_strings(6);
             $tableNamePin = 'auth_pin';
             //create a query to add to a second table in the database
             $query2 = "INSERT INTO $tableNamePin (Acc_Email, OTP) VALUES ('$email', '$shuffle');";
             //run the query on the database
             $result2 = mysqli_query($dbConnect, $query2);

             //use the PHPMailer functions to send the 6-digit code to the email address for the account --> communicates with on-server SMTP solution
             $mail = new PHPMailer(true);
             try {
               $mail->isSMTP();
               $mail->Host = '192.168.1.241';               //SMTP host IP
               $mail->SMTPAuth = true;
               $mail->Username = 'no-reply@webDevCOSC.com';   //SMTP username
               $mail->Password = 'Climatal11!';               //SMTP password
               $mail->port = 25;

               $mail->setFrom('no-reply@webDevCOSC.com');     //Send From Address - domain is fake
               $mail->addAddress($email);                   //send To addres

               $mail->isHTML(true);
               $mail->Subject = '2-Factor Authentication Code';
                                                                                          //subject and body
               $body = '<p>Hello, your 2-Factor Authentication Code is: </p>'.$shuffle;

               $mail->Body = $body;
               $mail->AltBody = strip_tags($body);

               $mail->send();
               echo 'Message has been sent';
             } catch (Exception $e) {
               echo 'Message could not be sent.';
               echo 'Mailer Error: ' . $mail->ErrorInfo;
             }

             //creation of session variables so we can share information across the session
             $tableNameUser = 'user_accounts';
             $sessionQuery = "SELECT Fname, Lname, Title FROM $tableNameUser WHERE Email='$email';";
             $results = mysqli_query($dbConnect,$sessionQuery);
             $rows = mysqli_fetch_array($results);

             $_SESSION['email'] = $email;
             $_SESSION['Fname'] = $Fname;
             $_SESSION['Lname'] = $Lname;
             $_SESSION['Title'] = $title;


             //redirect the user to the 2-factor authentication page
             header("Location:http://138.88.73.64/2FAProject/2FAPage/2fa.php");
             exit;
          }
       }
   }
   mysqli_close($dbConnect);
?>
<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - Sign-Up</title>
      <style>
        @import url("../style/style.css");
      </style>
  </head>
  <body>
    <form method='POST'>
    <div id="mainBody">
        <div id="innerbodySU">
            <div id="titleBoxSU">
                <h1>Account Sign-Up</h1>
            </div>
            <br>
            <br>
            <div id="leftSideSU">
              <p><b>First Name:</b></p>
                <input class="input" type="text" id="Fname" name="FirstName" placeholder="e.x. John" minlength="1" maxlength="30">
              <p><b>Last Name:</b></p>
                <input class="input" type="text" id="Lname" name="LastName" placeholder="e.x. Doe" minlength="1" maxlength="30">
              <p><b>Title: </b><select name="title" style="width: 100px; font-size:20px">
                              <option>Mr.</option>
                              <option>Mrs.</option>
                              <option>Ms.</option>
                              <option>Miss.</option>
                            </select></p>
              <p><b>Email:</B></p>
                <input class="input" type="text" id="Email" name="EmailAddr" placeholder="e.x. jDoe@email.com" minlength="1" maxlength="50">
            </div>

            <div id="rightSideSU">
              <p><b>Password:</b></p>
                <input class="input" type="password" id="Pass" name="Pass" minlength="1" maxlength="30">
              <p><b>Confirm Password:</b></p>
                <input class="input" type="password" id="Pass2" name="Pass2" minlength="1" maxlength="30">
            </div>
            <br>
            <br>
            <br>
            <input class="subButtonSU" type="submit" name="Submit" value="Sign-Up"><input class="accButtonSU" type="button" value="Already Have an Account? Click Here" onclick="location.href='../Login/Login.php'">
        </div>
    </div>
  </form>
  </body>
</html>
