<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../phpmailer/vendor/autoload.php';
   //Establishes the Connection to the Database
   //require '../dbConnect.php';
   $dbConnect = mysqli_connect("138.88.73.64", "amorphew", "Climatal11!", "amorphew");
   //prints based on if the connection is correct
   if($dbConnect == false) {
     print "Unable to connect to the database: " . mysqli_errno();
   }
   else {
     if(isset($_POST['Submit']))
     {
         $email = mysqli_real_escape_string($dbConnect,$_POST['EmailAddr']); //capture the username from the input
         $password = mysqli_real_escape_string($dbConnect,$_POST['Pass']); //capture the password entered by the

         if ($email != "" && $password != "")
         {
            $tableNameUser = 'user_accounts';
             //select the number of accounts with the similar email address (should one be one email)
             $sql_query = "SELECT COUNT(email) AS cntUser FROM $tableNameUser WHERE Email='$email';";
             $result = mysqli_query($dbConnect,$sql_query);
             $row = mysqli_fetch_array($result);

             //select the hashed password from the database from the account with the matching email address (username)
             $sql_query2 = "SELECT password FROM $tableNameUser WHERE Email='$email';";
             $result2 = mysqli_query($dbConnect,$sql_query2);
             $row2 = mysqli_fetch_array($result2);

             $count = $row['cntUser'];
             $dbpass = $row2['password'];

             //verify that their is only one account with the email, and that the passwrod entered matches the account
             if($count == 1 && password_verify($password, $dbpass)) //must hash the entered password and compare it to the hash of the password stored
             {
                 //similar function to create a random 6-digit string
                 function random_strings($length_of_string)
                 {

                    // String of all alphanumeric character
                    $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';

                    // Shufle the $str_result and returns substring
                    // of specified length
                    return substr(str_shuffle($str_result), 0, $length_of_string);
                  }
                  //create a 6-digit random string using the function above
                  $shuffle = random_strings(6);
                  $tableNamePin = 'auth_pin';
                  //create a query to add to a second table in the database
                  $query2 = "INSERT INTO $tableNamePin (Acc_Email, OTP) VALUES ('$email', '$shuffle');";
                  //run the query on the database
                  $result2 = mysqli_query($dbConnect, $query2);

                 //PHPMailer function to send the code to the accounts email address - communicates with SMTP server on host server

                 $mail = new PHPMailer(true);
                 try {
                   $mail->isSMTP();
                   $mail->Host = '192.168.1.241';               //host address to SMTP server
                   $mail->SMTPAuth = true;
                   $mail->Username = 'no-reply@webDevCOSC.com';   //SMTP account username
                   $mail->Password = 'Climatal11!';               //SMTP account authentication password
                   $mail->port = 25;

                   $mail->setFrom('no-reply@webDevCOSC.com');     //specifying Send From address - fake domain
                   $mail->addAddress($email);                   //specifying Send To address

                   $mail->isHTML(true);
                   $mail->Subject = '2-Factor Authentication Code';
                                                                                              //subject and body
                   $body = '<p>Hello, your 2-Factor Authentication Code is: </p>'.$shuffle;

                   $mail->Body = $body;
                   $mail->AltBody = strip_tags($body);

                   $mail->send();
                   echo 'Message has been sent';
                 } catch (Exception $e) {
                   echo 'Message could not be sent.';
                   echo 'Mailer Error: ' . $mail->ErrorInfo;
                 }

                 //saving variables to a session
                 $tableNameUser = 'user_accounts';
                 $sessionQuery = "SELECT Fname, Lname, Title FROM $tableNameUser WHERE Email='$email';";
                 $results = mysqli_query($dbConnect,$sessionQuery);
                 $rows = mysqli_fetch_array($results);

                 $_SESSION['email'] = $email;
                 $_SESSION['Fname'] = $rows['Fname'];
                 $_SESSION['Lname'] = $rows['Lname'];
                 $_SESSION['Title'] = $rows['Title'];

                 //redirect the user to the 2FA page
                 header("Location:http://138.88.73.64/2FAProject/2FAPage/2fa.php");
                 exit();
             }
             else
             {
                 //echo and error - incorect inputs that do not match an account
                 echo "<script type ='text/javascript'>alert('Incorrect Username or Password')</script>";
             }

         }
     }
  }
  mysqli_close($dbConnect);
?>



<!DOCTYPE php>
<meta charset='UTF-8'>
<html lang='en'>
  <head>
      <title>2FA Project - Login</title>
      <style>
        @import url("../style/style.css");
      </style>
  </head>
  <body>
    <form method='POST'>
    <div id="mainBody">
        <div id="innerbodySU">
            <div id="titleBoxSU">
                <h1>Account Login</h1>
            </div>
            <br>
            <br>
            <br>
            <br>
            <div id="lowerLog">
              <p><b>Email:</b></p>
                <input style="height:20%;" class="input" type="text" id="Email" name="EmailAddr" placeholder="e.x. jDoe@email.com" minlength="1" maxlength="50">
              <p><b>Password:</b></p>
                <input style="height:20%;" class="input" type="password" id="Pass" name="Pass" minlength="1" maxlength="30">
            </div>

            <br>
            <br>
            <br>
            <input class="subButtonSU" type="submit" name="Submit" value="Login"><input class="accButtonSU" type="button" value="Don't Have an Account? Click Here" onclick="location.href='../SignUp/SignUp.php'">
        </div>
    </div>
  </form>
  </body>
</html>
